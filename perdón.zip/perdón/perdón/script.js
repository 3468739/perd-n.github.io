"use strict";

const titleElement = document.querySelector(".title");
const buttonsContainer = document.querySelector(".buttons");
const shiButton = document.querySelector(".btn--shi");
const ñoButton = document.querySelector(".btn--ño");
const catImg = document.querySelector(".cat-img");

const MAX_IMAGES = 5;

let play = true;
let ñoCount = 0;

shiButton.addEventListener("click", handleShiClick);

ñoButton.addEventListener("click", function () {
  if (play) {
    ñoCount++;
    const imageIndex = Math.min(ñoCount, MAX_IMAGES);
    changeImage(imageIndex);
    resizeShiButton();
    updateÑoButtonText();
    if (ñoCount === MAX_IMAGES) {
      play = false;
    }
  }
});

function handleShiClick() {
  titleElement.innerHTML = "TE AMO MI AMOR, GRACIAS, NO PASARA OTRA VEZ";
  buttonsContainer.classList.add("hidden");
  changeImage("shi");
}

function resizeShiButton() {
  const computedStyle = window.getComputedStyle(shiButton);
  const fontSize = parseFloat(computedStyle.getPropertyValue("font-size"));
  const newFontSize = fontSize * 1.6;

  shiButton.style.fontSize = `${newFontSize}px`;
}

function generateMessage(ñoCount) {
  const messages = [
    "Ño",
    "Seguro?",
    "Porfisssss",
    "Deja de picarle aqui, perdooon",
    "andaleeee, perdoname mi amor",
    "Voy a llorar...",
  ];

  const messageIndex = Math.min(ñoCount, messages.length - 1);
  return messages[messageIndex];
}

function changeImage(image) {
  catImg.src = `img/cat-${image}.jpg`;
}

function updateÑoButtonText() {
  ñoButton.innerHTML = generateMessage(ñoCount);
}
